from django.apps import AppConfig


class InformacionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Informacion'
